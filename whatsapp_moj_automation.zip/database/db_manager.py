"""
Database Manager Module
SQLite database operations for the MOJ Automation System
"""
import sqlite3
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from config.settings import DB_PATH
from utils.logger import setup_logger

logger = setup_logger("DatabaseManager")


class DatabaseManager:
    """
    Manages all SQLite database operations
    Handles transactions, lawyer mappings, and message tracking
    """

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._init_database()
        logger.info(f"Database initialized at {db_path}")

    def _get_connection(self) -> sqlite3.Connection:
        """Create database connection with proper settings"""
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        return conn

    def _init_database(self):
        """Initialize database tables"""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Main transactions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app_number TEXT UNIQUE NOT NULL,
                    client_name TEXT NOT NULL,
                    lawyer_name TEXT,
                    whatsapp_group TEXT NOT NULL,
                    transaction_type TEXT DEFAULT 'e-notary',
                    payment_link TEXT,
                    message_date TEXT,
                    is_broker INTEGER DEFAULT 0,
                    gross_amount REAL DEFAULT 0.0,
                    commission_percent REAL DEFAULT 20.0,
                    commission_amount REAL DEFAULT 0.0,
                    net_amount REAL DEFAULT 0.0,
                    status TEXT DEFAULT 'pending',
                    language TEXT,
                    message_id TEXT UNIQUE,
                    raw_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Lawyer mappings table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS lawyer_mappings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app_number TEXT UNIQUE NOT NULL,
                    lawyer_name TEXT NOT NULL,
                    group_name TEXT,
                    message_text TEXT,
                    mapped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Processed messages tracking
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS processed_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id TEXT UNIQUE NOT NULL,
                    group_name TEXT,
                    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Daily stats table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS daily_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    stat_date TEXT UNIQUE NOT NULL,
                    total_transactions INTEGER DEFAULT 0,
                    total_commission REAL DEFAULT 0.0,
                    total_gross REAL DEFAULT 0.0,
                    unmatched_count INTEGER DEFAULT 0,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Create indexes for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_app_number ON transactions(app_number)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_lawyer ON transactions(lawyer_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_date ON transactions(message_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_status ON transactions(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_group ON transactions(whatsapp_group)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_lawyer_map ON lawyer_mappings(app_number)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_processed ON processed_messages(message_id)")

            conn.commit()
            logger.info("Database tables initialized successfully")

    # ==================== TRANSACTION OPERATIONS ====================

    def add_transaction(self, data: Dict[str, Any]) -> bool:
        """
        Add new transaction to database

        Args:
            data: Transaction data dictionary

        Returns:
            True if added successfully, False if duplicate
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                # Check for duplicate
                cursor.execute(
                    "SELECT id FROM transactions WHERE app_number = ?",
                    (data.get("app_number"),)
                )
                if cursor.fetchone():
                    logger.warning(f"Duplicate transaction: {data.get('app_number')}")
                    return False

                # Calculate financials
                gross = float(data.get("gross_amount", 0))
                commission_pct = float(data.get("commission_percent", 20.0))
                commission = gross * (commission_pct / 100)
                net = gross - commission

                cursor.execute("""
                    INSERT INTO transactions (
                        app_number, client_name, lawyer_name, whatsapp_group,
                        transaction_type, payment_link, message_date, is_broker,
                        gross_amount, commission_percent, commission_amount, net_amount,
                        status, language, message_id, raw_message
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    data.get("app_number"),
                    data.get("client_name"),
                    data.get("lawyer_name"),
                    data.get("whatsapp_group"),
                    data.get("transaction_type", "e-notary"),
                    data.get("payment_link"),
                    data.get("message_date"),
                    1 if data.get("is_broker") else 0,
                    gross,
                    commission_pct,
                    commission,
                    net,
                    data.get("status", "pending"),
                    data.get("language"),
                    data.get("message_id"),
                    data.get("raw_message")
                ))

                conn.commit()
                logger.info(f"Transaction added: {data.get('app_number')} - {data.get('client_name')}")
                return True

        except sqlite3.IntegrityError as e:
            logger.warning(f"Integrity error for {data.get('app_number')}: {e}")
            return False
        except Exception as e:
            logger.error(f"Error adding transaction: {e}")
            return False

    def update_transaction_status(self, app_number: str, status: str) -> bool:
        """Update transaction status"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "UPDATE transactions SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE app_number = ?",
                    (status, app_number)
                )
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error updating status: {e}")
            return False

    def update_transaction_amounts(self, app_number: str, gross_amount: float) -> bool:
        """Update financial amounts for a transaction"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                # Get current commission percent
                cursor.execute(
                    "SELECT commission_percent FROM transactions WHERE app_number = ?",
                    (app_number,)
                )
                row = cursor.fetchone()
                if not row:
                    return False

                commission_pct = row["commission_percent"]
                commission = gross_amount * (commission_pct / 100)
                net = gross_amount - commission

                cursor.execute("""
                    UPDATE transactions 
                    SET gross_amount = ?, commission_amount = ?, net_amount = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE app_number = ?
                """, (gross_amount, commission, net, app_number))

                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error updating amounts: {e}")
            return False

    def get_transaction_by_app_number(self, app_number: str) -> Optional[Dict]:
        """Get transaction by application number"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM transactions WHERE app_number = ?",
                    (app_number,)
                )
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error fetching transaction: {e}")
            return None

    def get_all_transactions(self, limit: int = 1000) -> List[Dict]:
        """Get all transactions ordered by date descending"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM transactions ORDER BY message_date DESC LIMIT ?",
                    (limit,)
                )
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error fetching transactions: {e}")
            return []

    def get_today_transactions(self) -> List[Dict]:
        """Get today's transactions"""
        today = datetime.now().strftime("%Y-%m-%d")
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM transactions WHERE date(message_date) = date(?) ORDER BY created_at DESC",
                    (today,)
                )
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error fetching today's transactions: {e}")
            return []

    def get_transactions_by_lawyer(self, lawyer_name: str) -> List[Dict]:
        """Get transactions for a specific lawyer"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM transactions WHERE lawyer_name = ? ORDER BY message_date DESC",
                    (lawyer_name,)
                )
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error fetching lawyer transactions: {e}")
            return []

    def get_unmatched_transactions(self) -> List[Dict]:
        """Get transactions without lawyer assignment"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM transactions WHERE lawyer_name IS NULL OR lawyer_name = '' ORDER BY created_at DESC"
                )
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error fetching unmatched: {e}")
            return []

    # ==================== LAWYER MAPPING OPERATIONS ====================

    def add_lawyer_mapping(self, app_number: str, lawyer_name: str, 
                          group_name: str = None, message_text: str = None) -> bool:
        """
        Add or update lawyer mapping for an application number

        Args:
            app_number: Application number
            lawyer_name: Lawyer name (from WhatsApp sender)
            group_name: Source group name
            message_text: Original message text

        Returns:
            True if successful
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                cursor.execute("""
                    INSERT INTO lawyer_mappings (app_number, lawyer_name, group_name, message_text)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(app_number) DO UPDATE SET
                        lawyer_name = excluded.lawyer_name,
                        group_name = excluded.group_name,
                        message_text = excluded.message_text,
                        updated_at = CURRENT_TIMESTAMP
                """, (app_number, lawyer_name, group_name, message_text))

                conn.commit()
                logger.info(f"Lawyer mapping: {app_number} -> {lawyer_name}")

                # Also update any existing transaction
                cursor.execute(
                    "UPDATE transactions SET lawyer_name = ?, updated_at = CURRENT_TIMESTAMP WHERE app_number = ? AND (lawyer_name IS NULL OR lawyer_name = '')",
                    (lawyer_name, app_number)
                )
                conn.commit()

                return True
        except Exception as e:
            logger.error(f"Error adding lawyer mapping: {e}")
            return False

    def get_lawyer_by_app_number(self, app_number: str) -> Optional[str]:
        """Get lawyer name by application number"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT lawyer_name FROM lawyer_mappings WHERE app_number = ?",
                    (app_number,)
                )
                row = cursor.fetchone()
                return row["lawyer_name"] if row else None
        except Exception as e:
            logger.error(f"Error fetching lawyer: {e}")
            return None

    def get_all_lawyer_mappings(self) -> List[Dict]:
        """Get all lawyer mappings"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM lawyer_mappings ORDER BY mapped_at DESC")
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error fetching mappings: {e}")
            return []

    # ==================== PROCESSED MESSAGES ====================

    def is_message_processed(self, message_id: str) -> bool:
        """Check if message was already processed"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT 1 FROM processed_messages WHERE message_id = ?",
                    (message_id,)
                )
                return cursor.fetchone() is not None
        except Exception as e:
            logger.error(f"Error checking processed: {e}")
            return False

    def mark_message_processed(self, message_id: str, group_name: str = None):
        """Mark message as processed"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR IGNORE INTO processed_messages (message_id, group_name)
                    VALUES (?, ?)
                """, (message_id, group_name))
                conn.commit()
        except Exception as e:
            logger.error(f"Error marking processed: {e}")

    # ==================== DASHBOARD STATS ====================

    def get_dashboard_stats(self) -> Dict[str, Any]:
        """Get statistics for dashboard"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                today = datetime.now().strftime("%Y-%m-%d")

                # Today's count
                cursor.execute(
                    "SELECT COUNT(*) as count FROM transactions WHERE date(message_date) = date(?)",
                    (today,)
                )
                today_count = cursor.fetchone()["count"]

                # Total count
                cursor.execute("SELECT COUNT(*) as count FROM transactions")
                total_count = cursor.fetchone()["count"]

                # Unmatched count
                cursor.execute(
                    "SELECT COUNT(*) as count FROM transactions WHERE lawyer_name IS NULL OR lawyer_name = ''"
                )
                unmatched_count = cursor.fetchone()["count"]

                # Total gross
                cursor.execute("SELECT COALESCE(SUM(gross_amount), 0) as total FROM transactions")
                total_gross = cursor.fetchone()["total"]

                # Total commission
                cursor.execute("SELECT COALESCE(SUM(commission_amount), 0) as total FROM transactions")
                total_commission = cursor.fetchone()["total"]

                # Transactions per lawyer
                cursor.execute("""
                    SELECT lawyer_name, COUNT(*) as count, SUM(gross_amount) as total
                    FROM transactions
                    WHERE lawyer_name IS NOT NULL AND lawyer_name != ''
                    GROUP BY lawyer_name
                    ORDER BY count DESC
                """)
                lawyer_stats = [dict(row) for row in cursor.fetchall()]

                # Transactions per group
                cursor.execute("""
                    SELECT whatsapp_group, COUNT(*) as count, SUM(gross_amount) as total
                    FROM transactions
                    GROUP BY whatsapp_group
                    ORDER BY count DESC
                """)
                group_stats = [dict(row) for row in cursor.fetchall()]

                return {
                    "today_count": today_count,
                    "total_count": total_count,
                    "unmatched_count": unmatched_count,
                    "total_gross": total_gross,
                    "total_commission": total_commission,
                    "lawyer_stats": lawyer_stats,
                    "group_stats": group_stats
                }
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {
                "today_count": 0, "total_count": 0, "unmatched_count": 0,
                "total_gross": 0, "total_commission": 0,
                "lawyer_stats": [], "group_stats": []
            }

    def cleanup_old_processed(self, days: int = 7):
        """Clean up processed messages older than specified days"""
        try:
            cutoff = datetime.now() - timedelta(days=days)
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "DELETE FROM processed_messages WHERE processed_at < ?",
                    (cutoff.isoformat(),)
                )
                conn.commit()
                logger.info(f"Cleaned up {cursor.rowcount} old processed messages")
        except Exception as e:
            logger.error(f"Error cleaning up: {e}")
