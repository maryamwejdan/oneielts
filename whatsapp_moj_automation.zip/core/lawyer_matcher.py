"""
Lawyer Matcher Module
Manages lawyer-application number mappings and auto-assignment
"""
from typing import Optional, Dict, Any
from database.db_manager import DatabaseManager
from utils.logger import setup_logger

logger = setup_logger("LawyerMatcher")


class LawyerMatcher:
    """
    Handles lawyer matching logic:
    - Extracts mappings from lawyer group messages
    - Stores mappings in database
    - Auto-assigns lawyers to payment transactions
    """

    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        logger.info("LawyerMatcher initialized")

    def process_lawyer_message(self, app_number: str, lawyer_name: str, 
                                group_name: str = None, message_text: str = None) -> bool:
        """
        Process a lawyer mapping message and store it

        Args:
            app_number: Application number
            lawyer_name: Lawyer name (from sender)
            group_name: Source WhatsApp group
            message_text: Original message text

        Returns:
            True if mapping was stored/updated
        """
        try:
            # Clean lawyer name
            lawyer_name = lawyer_name.strip()
            if not lawyer_name or lawyer_name.lower() in ["unknown", "", "null"]:
                logger.warning(f"Invalid lawyer name for app {app_number}")
                return False

            # Store mapping
            success = self.db.add_lawyer_mapping(
                app_number=app_number,
                lawyer_name=lawyer_name,
                group_name=group_name,
                message_text=message_text
            )

            if success:
                logger.info(f"Lawyer mapped: {app_number} -> {lawyer_name}")

                # Try to update any existing unmatched transaction
                self._update_unmatched_transaction(app_number, lawyer_name)

            return success

        except Exception as e:
            logger.error(f"Error processing lawyer message: {e}")
            return False

    def get_lawyer_for_app(self, app_number: str) -> Optional[str]:
        """
        Get lawyer name for an application number

        Args:
            app_number: Application number

        Returns:
            Lawyer name or None
        """
        return self.db.get_lawyer_by_app_number(app_number)

    def _update_unmatched_transaction(self, app_number: str, lawyer_name: str):
        """
        Update existing transaction with newly found lawyer mapping
        """
        try:
            transaction = self.db.get_transaction_by_app_number(app_number)
            if transaction and (not transaction.get("lawyer_name") or transaction.get("lawyer_name") == ""):
                self.db.update_transaction_status(app_number, "matched")
                logger.info(f"Updated unmatched transaction {app_number} with lawyer {lawyer_name}")
        except Exception as e:
            logger.error(f"Error updating unmatched: {e}")

    def get_all_mappings(self) -> Dict[str, str]:
        """
        Get all lawyer mappings as dictionary

        Returns:
            Dict mapping app_number -> lawyer_name
        """
        mappings = self.db.get_all_lawyer_mappings()
        return {m["app_number"]: m["lawyer_name"] for m in mappings}

    def get_mapping_stats(self) -> Dict[str, Any]:
        """
        Get statistics about lawyer mappings

        Returns:
            Statistics dictionary
        """
        mappings = self.db.get_all_lawyer_mappings()

        # Count per lawyer
        lawyer_counts = {}
        for m in mappings:
            name = m["lawyer_name"]
            lawyer_counts[name] = lawyer_counts.get(name, 0) + 1

        return {
            "total_mappings": len(mappings),
            "unique_lawyers": len(lawyer_counts),
            "lawyer_distribution": lawyer_counts
        }
