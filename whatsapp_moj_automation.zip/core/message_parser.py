"""
Message Parser Module
Extracts payment and lawyer information from WhatsApp messages
Uses regex as primary method with AI fallback
"""
import re
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass
from config.settings import (
    ARABIC_PAYMENT_PATTERN, ARABIC_PAYMENT_PATTERN_FALLBACK,
    ENGLISH_PAYMENT_PATTERN, ENGLISH_PAYMENT_PATTERN_FALLBACK,
    LAWYER_APP_PATTERN
)
from utils.logger import setup_logger
from utils.helpers import detect_language, clean_text

logger = setup_logger("MessageParser")


@dataclass
class PaymentData:
    """Data class for extracted payment information"""
    app_number: str
    client_name: str
    payment_link: str
    language: str
    raw_message: str
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "app_number": self.app_number,
            "client_name": self.client_name,
            "payment_link": self.payment_link,
            "language": self.language,
            "raw_message": self.raw_message,
            "is_valid": self.is_valid
        }


@dataclass
class LawyerMapping:
    """Data class for lawyer mapping information"""
    app_number: str
    lawyer_name: str
    raw_message: str
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "app_number": self.app_number,
            "lawyer_name": self.lawyer_name,
            "raw_message": self.raw_message,
            "is_valid": self.is_valid
        }


class MessageParser:
    """
    Parses WhatsApp messages to extract structured data
    Primary: Regex patterns
    Fallback: AI-based extraction (rule-based heuristics)
    """

    def __init__(self):
        self.arabic_pattern = re.compile(ARABIC_PAYMENT_PATTERN, re.IGNORECASE | re.DOTALL)
        self.arabic_fallback = re.compile(ARABIC_PAYMENT_PATTERN_FALLBACK, re.IGNORECASE | re.DOTALL)
        self.english_pattern = re.compile(ENGLISH_PAYMENT_PATTERN, re.IGNORECASE | re.DOTALL)
        self.english_fallback = re.compile(ENGLISH_PAYMENT_PATTERN_FALLBACK, re.IGNORECASE | re.DOTALL)
        self.lawyer_pattern = re.compile(LAWYER_APP_PATTERN, re.MULTILINE)

        logger.info("MessageParser initialized with regex patterns")

    def parse_payment_message(self, message_text: str) -> Optional[PaymentData]:
        """
        Parse payment message using regex first, then AI fallback

        Args:
            message_text: Raw message text from WhatsApp

        Returns:
            PaymentData object or None
        """
        text = clean_text(message_text)
        language = detect_language(text)

        logger.debug(f"Parsing payment message ({language}): {text[:100]}...")

        # Try primary regex patterns
        if language == "arabic":
            result = self._try_arabic_patterns(text)
        else:
            result = self._try_english_patterns(text)

        if result:
            logger.info(f"Parsed payment: App={result.app_number}, Client={result.client_name}")
            return result

        # AI Fallback: Rule-based heuristic extraction
        logger.debug("Regex failed, trying AI fallback...")
        result = self._ai_fallback_parse(text, language)

        if result and result.is_valid:
            logger.info(f"AI fallback parsed: App={result.app_number}, Client={result.client_name}")
            return result

        logger.debug("Failed to parse payment message")
        return None

    def _try_arabic_patterns(self, text: str) -> Optional[PaymentData]:
        """Try Arabic regex patterns"""
        # Primary pattern
        match = self.arabic_pattern.search(text)
        if match:
            return PaymentData(
                app_number=match.group(1).strip(),
                client_name=match.group(2).strip(),
                payment_link=match.group(3).strip(),
                language="arabic",
                raw_message=text
            )

        # Fallback pattern
        match = self.arabic_fallback.search(text)
        if match:
            return PaymentData(
                app_number=match.group(1).strip(),
                client_name=match.group(2).strip().split("
")[0].strip(),
                payment_link=match.group(3).strip(),
                language="arabic",
                raw_message=text
            )

        return None

    def _try_english_patterns(self, text: str) -> Optional[PaymentData]:
        """Try English regex patterns"""
        # Primary pattern
        match = self.english_pattern.search(text)
        if match:
            return PaymentData(
                app_number=match.group(1).strip(),
                client_name=match.group(2).strip(),
                payment_link=match.group(3).strip(),
                language="english",
                raw_message=text
            )

        # Fallback pattern
        match = self.english_fallback.search(text)
        if match:
            return PaymentData(
                app_number=match.group(1).strip(),
                client_name=match.group(2).strip().split("
")[0].strip(),
                payment_link=match.group(3).strip(),
                language="english",
                raw_message=text
            )

        return None

    def _ai_fallback_parse(self, text: str, language: str) -> Optional[PaymentData]:
        """
        AI Fallback: Rule-based heuristic extraction
        Uses pattern recognition when regex fails
        """
        try:
            # Extract application number (6-7 digits typically)
            app_numbers = re.findall(r'(\d{5,7})', text)
            if not app_numbers:
                return None
            app_number = app_numbers[0]

            # Extract URL
            urls = re.findall(r'https?://[^\s<>"{}|\^`\[\]]+', text)
            if not urls:
                return None
            payment_link = urls[0]

            # Extract client name using heuristics
            client_name = self._extract_name_heuristic(text, language, app_number, payment_link)

            if client_name and app_number and payment_link:
                return PaymentData(
                    app_number=app_number,
                    client_name=client_name,
                    payment_link=payment_link,
                    language=language,
                    raw_message=text,
                    is_valid=True
                )

            return None

        except Exception as e:
            logger.error(f"AI fallback error: {e}")
            return None

    def _extract_name_heuristic(self, text: str, language: str, 
                                 app_number: str, payment_link: str) -> Optional[str]:
        """
        Extract client name using position-based heuristics
        """
        try:
            # Find positions
            app_pos = text.find(app_number)
            link_pos = text.find(payment_link)

            if app_pos == -1 or link_pos == -1:
                return None

            # Name is usually between app number and link
            if app_pos < link_pos:
                between_text = text[app_pos + len(app_number):link_pos]
            else:
                between_text = text[link_pos + len(payment_link):app_pos]

            # Clean up
            between_text = re.sub(r'[:\-\|،,\.\(\)\[\]\{\}]', ' ', between_text)
            between_text = re.sub(r'\s+', ' ', between_text).strip()

            # For Arabic, look for names after "لـ:" or "لـ"
            if language == "arabic":
                name_markers = ["لـ:", "لـ ", "assigned to", "ل "]
                for marker in name_markers:
                    if marker in between_text:
                        parts = between_text.split(marker)
                        if len(parts) > 1:
                            candidate = parts[-1].strip()
                            # Take first 3-4 words as name
                            words = candidate.split()
                            if words:
                                return " ".join(words[:4])

            # For English, look for "assigned to" or take words before link
            if language == "english":
                if "assigned to" in between_text.lower():
                    parts = between_text.lower().split("assigned to")
                    if len(parts) > 1:
                        candidate = parts[-1].strip()
                        words = candidate.split()
                        return " ".join(words[:4])

            # Generic: take the longest sequence of words that looks like a name
            words = between_text.split()
            if words:
                # Filter out common non-name words
                skip_words = {"pay", "fee", "application", "number", "the", "for", 
                             "يمكنكم", "دفع", "رسم", "طلبكم", "رقم", "من", "خلال",
                             "الرابط", "التالي", "المخصص"}
                filtered = [w for w in words if w.lower() not in skip_words and len(w) > 1]
                if filtered:
                    return " ".join(filtered[:4])
                return " ".join(words[:4])

            return None

        except Exception as e:
            logger.error(f"Name extraction error: {e}")
            return None

    def parse_lawyer_message(self, message_text: str, sender_name: str) -> Optional[LawyerMapping]:
        """
        Parse lawyer approval message
        Format: "681476 انجليزي" or "681331 مع ترجم"

        Args:
            message_text: Raw message text
            sender_name: WhatsApp sender name (lawyer name)

        Returns:
            LawyerMapping object or None
        """
        text = clean_text(message_text)

        logger.debug(f"Parsing lawyer message from {sender_name}: {text[:100]}...")

        # Try primary pattern
        match = self.lawyer_pattern.match(text)
        if match:
            app_number = match.group(1).strip()
            # Validate: should be 5-7 digits
            if app_number.isdigit() and 5 <= len(app_number) <= 7:
                return LawyerMapping(
                    app_number=app_number,
                    lawyer_name=sender_name.strip(),
                    raw_message=text
                )

        # Fallback: find any 5-7 digit number at start or in message
        numbers = re.findall(r'(\d{5,7})', text)
        if numbers:
            app_number = numbers[0]
            return LawyerMapping(
                app_number=app_number,
                lawyer_name=sender_name.strip(),
                raw_message=text
            )

        logger.debug("Failed to parse lawyer message")
        return None

    def is_payment_message(self, text: str) -> bool:
        """Quick check if message is likely a payment message"""
        text_lower = text.lower()
        indicators = [
            "enotary.moj.gov.ae",
            "application number",
            "pay the fee",
            "رسم طلبكم",
            "يمكنكم دفع",
            "طلبكم رقم",
            "assigned to"
        ]
        return any(ind in text_lower for ind in indicators)

    def is_lawyer_message(self, text: str) -> bool:
        """Quick check if message is likely a lawyer mapping message"""
        # Check for pattern: number followed by Arabic text
        if re.match(r'^\d{5,7}\s+', text.strip()):
            return True
        return False
