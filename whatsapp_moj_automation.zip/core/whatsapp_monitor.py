"""
WhatsApp Web Monitor Module
Monitors WhatsApp Web groups using Selenium
Handles QR login, message extraction, and reconnection
"""
import time
import threading
from datetime import datetime
from typing import List, Dict, Any, Optional, Callable
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import (
    NoSuchElementException, TimeoutException, 
    StaleElementReferenceException, WebDriverException
)
from webdriver_manager.chrome import ChromeDriverManager
from config.settings import (
    WHATSAPP_URL, QR_TIMEOUT, MESSAGE_POLL_INTERVAL,
    RECONNECT_INTERVAL, MAX_RECONNECT_ATTEMPTS
)
from utils.logger import setup_logger
from utils.helpers import generate_message_id, parse_whatsapp_timestamp

logger = setup_logger("WhatsAppMonitor")


class WhatsAppMonitor:
    """
    WhatsApp Web monitor using Selenium
    Features:
    - Multi-group monitoring
    - QR code login handling
    - Auto-reconnection
    - New message detection
    - Duplicate prevention
    """

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.driver: Optional[webdriver.Chrome] = None
        self.wait: Optional[WebDriverWait] = None
        self.is_connected = False
        self.is_running = False
        self.reconnect_attempts = 0
        self.monitored_groups: List[str] = []
        self.message_callbacks: List[Callable] = []
        self._last_messages: Dict[str, List[str]] = {}  # group -> message IDs
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        logger.info("WhatsAppMonitor initialized")

    def _init_driver(self) -> webdriver.Chrome:
        """Initialize Chrome WebDriver with proper options"""
        chrome_options = Options()

        if self.headless:
            chrome_options.add_argument("--headless=new")

        # Essential options for WhatsApp Web
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-infobars")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0")

        # Persist session
        chrome_options.add_argument("--profile-directory=Default")
        chrome_options.add_argument("--user-data-dir=./chrome_profile")

        # Preferences
        prefs = {
            "profile.default_content_setting_values.notifications": 2,
            "profile.managed_default_content_settings.images": 2  # Disable images for speed
        }
        chrome_options.add_experimental_option("prefs", prefs)

        try:
            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=chrome_options)
            driver.implicitly_wait(10)
            logger.info("Chrome WebDriver initialized")
            return driver
        except Exception as e:
            logger.error(f"Failed to initialize WebDriver: {e}")
            raise

    def connect(self) -> bool:
        """
        Connect to WhatsApp Web and handle QR code login

        Returns:
            True if connected successfully
        """
        try:
            if self.driver:
                try:
                    self.driver.quit()
                except:
                    pass

            self.driver = self._init_driver()
            self.wait = WebDriverWait(self.driver, QR_TIMEOUT)

            logger.info("Navigating to WhatsApp Web...")
            self.driver.get(WHATSAPP_URL)

            # Wait for QR scan or direct login
            logger.info("Waiting for QR code scan (or auto-login if previously authenticated)...")

            # Check if already logged in (chat list appears)
            try:
                WebDriverWait(self.driver, 5).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "[data-testid='chat-list']"))
                )
                logger.info("Already logged in!")
                self.is_connected = True
                self.reconnect_attempts = 0
                return True
            except TimeoutException:
                pass

            # Wait for QR code to be scanned
            try:
                # QR code element
                qr_element = WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "[data-testid='qr-code']"))
                )
                logger.info("QR code displayed. Please scan with your phone.")

                # Wait for login completion
                self.wait.until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "[data-testid='chat-list']"))
                )
                logger.info("QR scanned successfully! Logged in.")
                self.is_connected = True
                self.reconnect_attempts = 0
                return True

            except TimeoutException:
                # Maybe already logged in, check for chat list
                try:
                    self.driver.find_element(By.CSS_SELECTOR, "[data-testid='chat-list']")
                    logger.info("Connected to WhatsApp Web")
                    self.is_connected = True
                    self.reconnect_attempts = 0
                    return True
                except NoSuchElementException:
                    logger.error("Failed to login - QR not scanned in time")
                    return False

        except Exception as e:
            logger.error(f"Connection error: {e}")
            return False

    def disconnect(self):
        """Disconnect from WhatsApp Web"""
        self.is_running = False
        self._stop_event.set()

        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=5)

        if self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                logger.warning(f"Error quitting driver: {e}")
            finally:
                self.driver = None

        self.is_connected = False
        logger.info("Disconnected from WhatsApp Web")

    def add_message_callback(self, callback: Callable):
        """Add callback function for new messages"""
        self.message_callbacks.append(callback)
        logger.debug(f"Added message callback: {callback.__name__}")

    def set_monitored_groups(self, groups: List[str]):
        """Set list of groups to monitor"""
        self.monitored_groups = groups
        logger.info(f"Monitoring groups: {groups}")

    def _find_group_chat(self, group_name: str) -> Optional[Any]:
        """
        Find and open a group chat by name

        Args:
            group_name: WhatsApp group name

        Returns:
            Chat element or None
        """
        try:
            # Search for group
            search_box = self.driver.find_element(
                By.CSS_SELECTOR, "[data-testid='chat-list-search']"
            )
            search_box.clear()
            search_box.send_keys(group_name)
            time.sleep(1)

            # Find chat in list
            chats = self.driver.find_elements(
                By.CSS_SELECTOR, "[data-testid='chat-list-item']"
            )

            for chat in chats:
                try:
                    title_elem = chat.find_element(By.CSS_SELECTOR, "[data-testid='chat-title']")
                    title = title_elem.text.strip()

                    if group_name.lower() in title.lower() or title.lower() in group_name.lower():
                        chat.click()
                        time.sleep(1)
                        logger.debug(f"Opened chat: {title}")
                        return chat

                except StaleElementReferenceException:
                    continue
                except Exception:
                    continue

            logger.warning(f"Group not found: {group_name}")
            return None

        except Exception as e:
            logger.error(f"Error finding group {group_name}: {e}")
            return None

    def _extract_messages_from_chat(self, group_name: str) -> List[Dict[str, Any]]:
        """
        Extract messages from currently open chat

        Returns:
            List of message dictionaries
        """
        messages = []

        try:
            # Find message containers
            msg_elements = self.driver.find_elements(
                By.CSS_SELECTOR, "[data-testid='msg-container']"
            )

            for msg_elem in msg_elements:
                try:
                    # Extract text
                    text_elements = msg_elem.find_elements(
                        By.CSS_SELECTOR, "[data-testid='msg-text'], .selectable-text"
                    )
                    text = " ".join([t.text for t in text_elements if t.text]).strip()

                    if not text:
                        continue

                    # Extract timestamp
                    time_elements = msg_elem.find_elements(
                        By.CSS_SELECTOR, "[data-testid='msg-meta']"
                    )
                    timestamp = ""
                    for t in time_elements:
                        spans = t.find_elements(By.TAG_NAME, "span")
                        if spans:
                            timestamp = spans[-1].text

                    # Extract sender (for group chats)
                    sender = ""
                    try:
                        sender_elem = msg_elem.find_element(
                            By.CSS_SELECTOR, "[data-testid='msg-sender']"
                        )
                        sender = sender_elem.text.strip()
                    except NoSuchElementException:
                        # Could be our own message
                        sender = "Me"

                    # Generate message ID
                    msg_id = generate_message_id(text, timestamp, sender)

                    messages.append({
                        "id": msg_id,
                        "text": text,
                        "timestamp": timestamp,
                        "sender": sender,
                        "group": group_name,
                        "datetime": parse_whatsapp_timestamp(timestamp)
                    })

                except StaleElementReferenceException:
                    continue
                except Exception as e:
                    logger.debug(f"Error extracting single message: {e}")
                    continue

            return messages

        except Exception as e:
            logger.error(f"Error extracting messages: {e}")
            return []

    def _process_new_messages(self, group_name: str, messages: List[Dict]):
        """Process new messages and trigger callbacks"""
        # Get previously seen message IDs for this group
        seen_ids = self._last_messages.get(group_name, set())

        new_messages = []
        for msg in messages:
            if msg["id"] not in seen_ids:
                new_messages.append(msg)
                seen_ids.add(msg["id"])

        self._last_messages[group_name] = seen_ids

        if new_messages:
            logger.info(f"Found {len(new_messages)} new messages in '{group_name}'")

            # Trigger callbacks
            for callback in self.message_callbacks:
                try:
                    callback(group_name, new_messages)
                except Exception as e:
                    logger.error(f"Callback error: {e}")

    def _monitor_loop(self):
        """Main monitoring loop running in separate thread"""
        logger.info("Monitor loop started")

        while not self._stop_event.is_set() and self.is_running:
            try:
                if not self.is_connected or not self.driver:
                    logger.warning("Not connected, attempting reconnection...")
                    if self.reconnect_attempts < MAX_RECONNECT_ATTEMPTS:
                        self.reconnect_attempts += 1
                        success = self.connect()
                        if not success:
                            logger.warning(f"Reconnection attempt {self.reconnect_attempts} failed")
                            self._stop_event.wait(RECONNECT_INTERVAL)
                            continue
                    else:
                        logger.error("Max reconnection attempts reached")
                        self.is_running = False
                        break

                # Monitor each group
                for group_name in self.monitored_groups:
                    if self._stop_event.is_set():
                        break

                    try:
                        # Open group chat
                        chat = self._find_group_chat(group_name)
                        if not chat:
                            continue

                        # Extract messages
                        messages = self._extract_messages_from_chat(group_name)

                        # Process new ones
                        self._process_new_messages(group_name, messages)

                        # Small delay between groups
                        time.sleep(1)

                    except Exception as e:
                        logger.error(f"Error monitoring group {group_name}: {e}")
                        continue

                # Wait before next poll
                self._stop_event.wait(MESSAGE_POLL_INTERVAL)

            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
                self.is_connected = False
                self._stop_event.wait(RECONNECT_INTERVAL)

        logger.info("Monitor loop stopped")

    def start_monitoring(self):
        """Start monitoring in background thread"""
        if not self.monitored_groups:
            logger.warning("No groups configured for monitoring")
            return False

        if not self.is_connected:
            logger.info("Connecting to WhatsApp Web...")
            if not self.connect():
                return False

        self.is_running = True
        self._stop_event.clear()

        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            daemon=True,
            name="WhatsAppMonitorThread"
        )
        self._monitor_thread.start()

        logger.info("Monitoring started")
        return True

    def stop_monitoring(self):
        """Stop monitoring"""
        self.is_running = False
        self._stop_event.set()

        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=10)

        logger.info("Monitoring stopped")

    def send_message(self, group_name: str, message: str) -> bool:
        """
        Send message to a group (for notifications)

        Args:
            group_name: Target group name
            message: Message text

        Returns:
            True if sent
        """
        try:
            chat = self._find_group_chat(group_name)
            if not chat:
                return False

            # Find input box
            input_box = self.driver.find_element(
                By.CSS_SELECTOR, "[data-testid='conversation-compose-box-input']"
            )
            input_box.send_keys(message)
            input_box.send_keys(Keys.ENTER)

            logger.info(f"Message sent to {group_name}")
            return True

        except Exception as e:
            logger.error(f"Error sending message: {e}")
            return False

    def get_connection_status(self) -> Dict[str, Any]:
        """Get current connection status"""
        return {
            "connected": self.is_connected,
            "running": self.is_running,
            "reconnect_attempts": self.reconnect_attempts,
            "monitored_groups": self.monitored_groups,
            "last_messages_count": {k: len(v) for k, v in self._last_messages.items()}
        }
